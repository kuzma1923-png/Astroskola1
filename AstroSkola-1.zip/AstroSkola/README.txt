# AstroŠkola – prvá funkčná verzia

## Obsah
- Náhodný 10-otázkový kvíz, 4 odpovede na otázku
- Vyhodnotenie, vysvetlenie a priamy odkaz na zdroj pri každej otázke
- Celková percentuálna úspešnosť a história testov
- Tematické vysvetlenia a informačné karty
- Pozorovací denník a osobné poznámky (ukladanie v prehliadači)
- Základná sekcia astronomických úkazov; bez vymyslených termínov
- Oddelený súbor otazky.json na rozširovanie databázy

## Spustenie
Najjednoduchšie: nahraj celý obsah priečinka na HTTPS hosting (napr. GitHub Pages alebo vlastný webhosting), potom otvor adresu v Chrome na Androide → menu ⋮ → „Pridať na plochu“ alebo „Inštalovať aplikáciu“.

Service worker a inštalácia PWA vyžadujú HTTPS (alebo localhost). Pri otvorení súboru priamo z archívu nemusí fungovať načítanie JSON a inštalácia.

## Dôležité obmedzenia tejto verzie
Toto je funkčný prototyp, nie hotový natívny APK. Aktuálny štartovací súbor obsahuje 24 otázok, nie deklarovaných 1 000. Každá z nich má vysvetlenie a zdroj. Databázu treba ďalej odborne rozšíriť a skontrolovať. Kvíz zatiaľ používa textové otázky; fotografie sa doplnia iba z reálnych archívov s overeným pôvodom a licenciou. Kalendár úkazov je zatiaľ pripravená sekcia, nie živý efemeridový feed.

Výsledky, denník a poznámky sa ukladajú lokálne v danom prehliadači/zariadení. Pred vymazaním dát prehliadača ich exportuj alebo zálohuj (export zatiaľ nie je implementovaný).
